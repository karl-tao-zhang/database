from mysqlpython import Mysqlpython

sqlh = Mysqlpython("root","123456","MOSHOU")

# sql_update = "update sheng set s_id=888888;"
# sqlh.zhixing(sql_update)

name = input("请输入添加的省名字:")
sql_insert = "insert into sheng(s_name) values(%s)"
sqlh.zhixing(sql_insert,[name])













